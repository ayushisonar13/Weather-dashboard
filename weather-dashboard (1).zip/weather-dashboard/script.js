// Weather Dashboard: uses the free Open-Meteo API (no API key needed)
const GEO_URL = "https://geocoding-api.open-meteo.com/v1/search";
const WEATHER_URL = "https://api.open-meteo.com/v1/forecast";

// WMO weather codes -> [description, emoji, sky type]
const CODES = {
  0: ["Clear sky", "☀️", "clear"], 1: ["Mostly clear", "🌤️", "clear"],
  2: ["Partly cloudy", "⛅", "cloud"], 3: ["Overcast", "☁️", "cloud"],
  45: ["Fog", "🌫️", "fog"], 48: ["Freezing fog", "🌫️", "fog"],
  51: ["Light drizzle", "🌦️", "rain"], 53: ["Drizzle", "🌦️", "rain"], 55: ["Heavy drizzle", "🌧️", "rain"],
  61: ["Light rain", "🌦️", "rain"], 63: ["Rain", "🌧️", "rain"], 65: ["Heavy rain", "🌧️", "rain"],
  71: ["Light snow", "🌨️", "snow"], 73: ["Snow", "❄️", "snow"], 75: ["Heavy snow", "❄️", "snow"],
  80: ["Rain showers", "🌦️", "rain"], 81: ["Rain showers", "🌧️", "rain"], 82: ["Violent showers", "⛈️", "storm"],
  95: ["Thunderstorm", "⛈️", "storm"], 96: ["Thunderstorm, hail", "⛈️", "storm"], 99: ["Thunderstorm, hail", "⛈️", "storm"],
};
const info = (code) => CODES[code] || ["Unknown", "🌡️", "cloud"];

const $ = (id) => document.getElementById(id);
const state = { data: null, place: "", unit: "C" };

// ---------- helpers ----------
const toUnit = (c) => Math.round(state.unit === "C" ? c : c * 9 / 5 + 32);
const fmtTemp = (c) => `${toUnit(c)}°`;
const setStatus = (msg, isError = false) => {
  const el = $("status");
  el.textContent = msg;
  el.classList.toggle("error", isError);
  el.hidden = !msg;
};

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("Network error. Please try again.");
  return res.json();
}

// ---------- data ----------
async function searchCity(name) {
  const data = await getJSON(`${GEO_URL}?name=${encodeURIComponent(name)}&count=1&language=en`);
  if (!data.results || !data.results.length) throw new Error(`No city found for "${name}". Check the spelling.`);
  const c = data.results[0];
  return { lat: c.latitude, lon: c.longitude, label: [c.name, c.admin1, c.country].filter(Boolean).join(", ") };
}

async function getWeather(lat, lon) {
  const params = new URLSearchParams({
    latitude: lat, longitude: lon, timezone: "auto", forecast_days: 6,
    current: "temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code,is_day",
    daily: "weather_code,temperature_2m_max,temperature_2m_min",
  });
  return getJSON(`${WEATHER_URL}?${params}`);
}

async function load(place) {
  setStatus("Loading weather…");
  try {
    state.data = await getWeather(place.lat, place.lon);
    state.place = place.label;
    render();
    setStatus("");
  } catch (err) {
    setStatus(err.message || "Something went wrong.", true);
  }
}

// ---------- render ----------
function render() {
  const { current, daily } = state.data;
  const [desc, emoji, sky] = info(current.weather_code);

  $("place").textContent = state.place;
  $("temp").textContent = fmtTemp(current.temperature_2m);
  $("desc").textContent = desc;
  $("icon").textContent = emoji;
  $("feels").textContent = fmtTemp(current.apparent_temperature);
  $("humidity").textContent = `${current.relative_humidity_2m}%`;
  $("wind").textContent = `${Math.round(current.wind_speed_10m)} km/h`;
  $("current").hidden = false;

  const night = current.is_day === 0;
  const type = night && ["clear", "cloud"].includes(sky) ? `${sky}-night` : ["clear", "cloud"].includes(sky) ? `${sky}-day` : sky;
  document.body.dataset.sky = type;

  // next 5 days (skip today at index 0)
  const box = $("forecast");
  box.innerHTML = "";
  for (let i = 1; i <= 5; i++) {
    const day = new Date(daily.time[i] + "T00:00");
    const [, e] = info(daily.weather_code[i]);
    const card = document.createElement("div");
    card.className = "day";
    card.innerHTML = `<div class="name">${day.toLocaleDateString("en", { weekday: "short" })}</div>
      <div class="emoji">${e}</div>
      <div class="hi">${fmtTemp(daily.temperature_2m_max[i])}</div>
      <div class="lo">${fmtTemp(daily.temperature_2m_min[i])}</div>`;
    box.appendChild(card);
  }
  box.hidden = false;
}

// ---------- recent searches ----------
function getRecent() {
  try { return JSON.parse(localStorage.getItem("recentCities")) || []; } catch { return []; }
}
function saveRecent(label, place) {
  const list = getRecent().filter((p) => p.label !== label);
  list.unshift(place);
  try { localStorage.setItem("recentCities", JSON.stringify(list.slice(0, 5))); } catch {}
  renderRecent();
}
function renderRecent() {
  const box = $("recent");
  box.innerHTML = "";
  getRecent().forEach((p) => {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = p.label.split(",")[0];
    b.title = p.label;
    b.onclick = () => load(p);
    box.appendChild(b);
  });
}

// ---------- events ----------
$("searchForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = $("cityInput").value.trim();
  if (!name) return;
  setStatus("Searching…");
  try {
    const place = await searchCity(name);
    await load(place);
    saveRecent(place.label, place);
  } catch (err) {
    setStatus(err.message, true);
  }
});

$("unitBtn").addEventListener("click", () => {
  state.unit = state.unit === "C" ? "F" : "C";
  $("unitBtn").textContent = `°${state.unit}`;
  if (state.data) render();
});

$("locBtn").addEventListener("click", () => {
  if (!navigator.geolocation) return setStatus("Your browser does not support location.", true);
  setStatus("Getting your location…");
  navigator.geolocation.getCurrentPosition(
    (pos) => load({ lat: pos.coords.latitude, lon: pos.coords.longitude, label: "Your location" }),
    () => setStatus("Location blocked. Allow access in your browser or search for a city.", true)
  );
});

renderRecent();
const last = getRecent()[0];
if (last) load(last);
