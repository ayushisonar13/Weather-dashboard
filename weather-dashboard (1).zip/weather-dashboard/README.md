# Weather Dashboard

A responsive weather web app. Search any city to see current conditions and a 5-day forecast. The background changes with the weather and time of day.

**Live demo:** https://YOUR-USERNAME.github.io/weather-dashboard/

## Features
- City search with geocoding
- Current temperature, feels-like, humidity and wind speed
- 5-day forecast
- °C / °F toggle
- "Use my location" button (browser geolocation)
- Recent searches saved in `localStorage`
- Background theme changes for clear, cloudy, rain, storm, snow, fog and night
- Loading and error states, keyboard accessible, mobile friendly

## Tech Stack
HTML5, CSS3 (Grid, Flexbox, custom properties), vanilla JavaScript (ES6, async/await, Fetch API)

**APIs:** [Open-Meteo](https://open-meteo.com/) Geocoding and Forecast APIs (free, no API key)

## Run Locally
```bash
git clone https://github.com/YOUR-USERNAME/weather-dashboard.git
cd weather-dashboard
# open index.html in your browser, or:
python -m http.server 8000   # then visit http://localhost:8000
```

## Project Structure
```
weather-dashboard/
├── index.html   # page structure
├── style.css    # layout and weather themes
├── script.js    # API calls, rendering, events
└── README.md
```

## How It Works
1. The city name is sent to the Open-Meteo geocoding API, which returns coordinates.
2. The coordinates are sent to the forecast API for current and daily data.
3. WMO weather codes are mapped to a description, icon and background theme.
4. Temperatures are stored in °C and converted to °F on display, so the unit toggle needs no extra API call.

## What I Learned
- Calling REST APIs with `fetch` and handling errors
- Chaining dependent async requests
- Updating the DOM from JSON data
- Responsive layout with CSS Grid
- Persisting data with `localStorage`

## Future Improvements
- Hourly forecast chart
- Air quality index
- Weather alerts

## License
MIT
